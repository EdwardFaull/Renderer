#include "RayTriangleIntersection.h"

RayTriangleIntersection::RayTriangleIntersection() = default;
RayTriangleIntersection::RayTriangleIntersection(const glm::vec3 &point, float distance, const ModelTriangle &triangle, glm::vec3 ray_incident, size_t index_t, size_t index_o) :
		intersectionPoint(point),
		distanceFromCamera(distance),
		intersectedTriangle(triangle),
		incidentRay(ray_incident),
		triangleIndex(index_t), 
		objectIndex(index_o),
		u(), 
		v() {}

std::ostream &operator<<(std::ostream &os, const RayTriangleIntersection &intersection) {
	os << "Intersection is at [" << intersection.intersectionPoint[0] << "," << intersection.intersectionPoint[1] << "," <<
	   intersection.intersectionPoint[2] << "] on triangle " << intersection.intersectedTriangle <<
	   " at a distance of " << intersection.distanceFromCamera;
	return os;
}
