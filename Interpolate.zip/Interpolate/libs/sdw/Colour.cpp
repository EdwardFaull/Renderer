#include "Colour.h"
#include <utility>

Colour::Colour() = default;
Colour::Colour(int r, int g, int b) : red(r), green(g), blue(b) {}
Colour::Colour(std::string n, int r, int g, int b) :
		name(std::move(n)),
		red(r), green(g), blue(b) {}

Colour::Colour(uint32_t x) {
	blue = x & 255;
	green = (x >> 8) & 255;
	red = (x >> 16) & 255;
}

uint32_t Colour::makeColourHex() {
	return (255 << 24) + (clamp(red, 0, 255) << 16) + (clamp(green, 0, 255) << 8) + clamp(blue, 0, 255);
}

uint32_t Colour::makeColourHex(int a, int b) {
	return (255 << 24) + (clamp(red, a, b) << 16) + (clamp(green, a, b) << 8) + clamp(blue, a, b);
}

std::ostream &operator<<(std::ostream &os, const Colour &colour) {
	os << colour.name << " ["
	   << colour.red << ", "
	   << colour.green << ", "
	   << colour.blue << "]";
	return os;
}

Colour operator+(Colour a, Colour b) {
	return Colour((float)a.red + (float)b.red, (float)a.green + (float)b.green, (float)a.blue + (float)b.blue);
}

Colour operator*(Colour a, float b) {
	return Colour((float)a.red * b, (float)a.green * b, (float)a.blue * b);
}

Colour operator*(Colour a, Colour b) {
	return Colour((float)a.red * (float)b.red, (float)a.green * (float)b.green, (float)a.blue * (float)b.blue);
}

Colour operator-(Colour a, Colour b) {
	return Colour(a.red - b.red, a.green - b.green, a.blue - b.blue);
}

Colour operator/(Colour a, float b) {
	return Colour((float)a.red / b, (float)a.green / b, (float)a.blue / b);
}