#include "CanvasTriangle.h"

CanvasTriangle::CanvasTriangle() = default;
CanvasTriangle::CanvasTriangle(const CanvasPoint &v0, const CanvasPoint &v1, const CanvasPoint &v2) :
    vertices({{v0, v1, v2}}) {}

void CanvasTriangle::sortPoints() {
    if (vertices[0].y > vertices[1].y)
        std::swap(vertices[0], vertices[1]);
    if (vertices[0].y > vertices[2].y) 
        std::swap(vertices[0], vertices[2]);
    if (vertices[1].y > vertices[2].y) 
        std::swap(vertices[1], vertices[2]);

    glm::vec2 top(vertices[0].x, vertices[0].y);
    glm::vec2 middle(vertices[1].x, vertices[1].y);
    glm::vec2 bottom(vertices[2].x, vertices[2].y);

    if (vertices[1].y == vertices[2].y) {

        float angleTopMiddle = glm::dot(glm::normalize(top), glm::normalize(middle));
        float angleTopBottom = glm::dot(glm::normalize(top), glm::normalize(bottom));

        if (angleTopBottom > angleTopMiddle) {
            std::swap(vertices[1], vertices[2]);
        }
    }

    if (vertices[1].y == vertices[0].y) {
        float angleBottomMiddle = glm::dot(glm::normalize(bottom), glm::normalize(middle));
        float angleBottomTop = glm::dot(glm::normalize(bottom), glm::normalize(top));

        if (angleBottomMiddle < angleBottomTop) {
            std::swap(vertices[1], vertices[0]);
        }
    }
}

CanvasPoint &CanvasTriangle::v0() {
    return vertices[0];
}

CanvasPoint &CanvasTriangle::v1() {
    return vertices[1];
}

CanvasPoint &CanvasTriangle::v2() {
    return vertices[2];
}

CanvasPoint CanvasTriangle::operator[](size_t i) const {
    return vertices[i];
}

CanvasPoint &CanvasTriangle::operator[](size_t i) {
    return vertices[i];
}

std::ostream &operator<<(std::ostream &os, const CanvasTriangle &triangle) {
	os << triangle[0] << triangle[1] << triangle[2];
	return os;
}
