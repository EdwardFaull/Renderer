#pragma once
#include <Utils.h>
#include <iostream>

struct Colour {
	std::string name;
	int red{};
	int green{};
	int blue{};
	Colour();
	Colour(int r, int g, int b);
	Colour(uint32_t x);
	Colour(std::string n, int r, int g, int b);
	uint32_t makeColourHex();
	uint32_t makeColourHex(int a, int b);
};

std::ostream &operator<<(std::ostream &os, const Colour &colour);

Colour operator+(Colour a, Colour b);
Colour operator*(Colour a, float b);
Colour operator-(Colour a, Colour b);
Colour operator/(Colour a, float b);
Colour operator*(Colour a, Colour b);