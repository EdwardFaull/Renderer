#pragma once

#include <string>
#include <vector>

#define PI 3.14159265358979323846f

std::vector<std::string> split(const std::string &line, char delimiter);

int clamp(int x, int a, int b);
float clamp(float x, float a, float b);
