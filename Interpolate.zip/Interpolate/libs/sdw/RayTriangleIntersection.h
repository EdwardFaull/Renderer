#pragma once

#include <glm/glm.hpp>
#include <iostream>
#include "ModelTriangle.h"

struct RayTriangleIntersection {
	glm::vec3 intersectionPoint;
	float distanceFromCamera;
	float u; float v;
	glm::vec3 incidentRay;
	ModelTriangle intersectedTriangle;
	size_t triangleIndex;
	size_t objectIndex;

	RayTriangleIntersection();
	RayTriangleIntersection(const glm::vec3 &point, float distance, const ModelTriangle &triangle, glm::vec3 ray_incident,
		size_t index_t, size_t index_o);
	friend std::ostream &operator<<(std::ostream &os, const RayTriangleIntersection &intersection);
};
