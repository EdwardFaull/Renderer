#pragma once
#include <SDL.h>
#undef main
#include <iostream>
#include <CanvasTriangle.h>
#include <DrawingWindow.h>
#include <Utils.h>
#include <fstream>
#include <vector>
#include <glm/glm.hpp>

glm::vec3 lerp(glm::vec3 a, glm::vec3 b, float c);
glm::mat3 lerp(glm::mat3 a, glm::mat3 b, float c);
float lerp(float a, float b, float c); 
CanvasPoint lerp(CanvasPoint a, CanvasPoint b, float c);
TexturePoint lerp(TexturePoint a, TexturePoint b, float c);

float rescale(float x, float upper, float lower, float newUpper, float newLower);
std::vector<float> SingleElementInterpolate(float in, float out, int steps);
void GreyscaleGradient(DrawingWindow& window);
std::vector<glm::vec3> InterpolateThreeElementValues(glm::vec3 from, glm::vec3 to, int numberOfValues);
std::vector<std::vector<glm::vec3>> SpectrumGradient(int W, int H);

std::vector<CanvasPoint> InterpolatePoints(CanvasPoint to, CanvasPoint from);
std::vector<TexturePoint> InterpolateTexturePoints(CanvasPoint to, CanvasPoint from);
