#pragma once
#include <glm/glm.hpp>

glm::mat3 yMatrix(float theta);
glm::mat3 xMatrix(float theta);

enum struct EngineType{Wireframe, Rasterised, Raytraced};

struct Camera {
	float orbitSpeed = 0.05;
	glm::mat3 orbitMat;

	float focalLength;
	glm::vec3 pos;
	glm::mat3 rot;

	EngineType engine;

	bool orbit;
	glm::vec3 orbitCenter;

	Camera(glm::vec3 pos, float f);
	void rotX(float theta);
	void rotY(float theta);
	void orbitCamera();
};

glm::mat3 lookAt(glm::vec3 target, glm::vec3 pos);