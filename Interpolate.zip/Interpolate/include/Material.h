#pragma once
#include <Colour.h>
#include <TextureMap.h>
#include <map>

#define SPECULAR_INTENSITY 500
#define SPECULAR_EXP 256

enum class MatType {Specular, Metallic, Refractive};
enum class ShadingType { Flat, Smooth };

struct Material {
	std::string name;
	MatType matType;
	Colour colour;
	Colour specColour;
	float specExp;
	float IoR;
	float roughness;
	ShadingType shadingType;
	std::string diffuseTextureID;
	std::string bumpTextureID;

	Material(std::string name, MatType matType, ShadingType shadingType);
	Material();
};

extern std::map<std::string, Material> materialAtlas;
extern std::map<std::string, TextureMap> textureAtlas;
