#include "Interpolate.h"
#include "Depth.h"
#include "CanvasTriangle.h"
#include "TextureMap.h"
#include "TexturePoint.h"
#include "Colour.h"
#include "Material.h"

void DrawLine(DrawingWindow& window, CanvasPoint from, CanvasPoint to, uint32_t colour);

void DrawTriangle(DrawingWindow& window, CanvasTriangle t, uint32_t colour);

void DrawTriangle(DrawingWindow& window, CanvasPoint p1, CanvasPoint p2, CanvasPoint p3, uint32_t colour);

void DrawFilledTriangle(DrawingWindow& window, CanvasTriangle t, uint32_t colour);

void DrawTexturedTriangle(DrawingWindow& window, CanvasTriangle triangle, Colour colour, std::string texture);

void DrawFilledTriangle(DrawingWindow& window, CanvasPoint p1, CanvasPoint p2, CanvasPoint p3, uint32_t colour);