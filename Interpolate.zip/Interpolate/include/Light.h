#include "Interpolate.h"
#include <Colour.h>

struct Light {
	glm::vec3 pos;
	float intensity;
	float radius;
	std::vector<glm::vec2> lightPoints;
	Colour colour;

	Light(glm::vec3 pos, float i, float r, Colour c);
	void generateLightPoints(float samples);
};