#pragma once
#include "Triangles.h"
#include "RayTriangleIntersection.h"
#include "Camera.h"
#include <ModelTriangle.h>
#include "Rasterise.h"
#include <thread>
#include <Light.h>
#include "Object.h"
#include "Material.h"
#include <random>
#include <stdlib.h>

#define THREADS 8
#define SHADING_SCHEME 0
#define SHADOW_BIAS 1e-4f
#define GLASS_BIAS 1e-2f
#define METAL_BIAS 1e-2f
#define METAL_SAMPLES 32
#define AMBIENT_MINIMUM 32.0f
#define LIGHT_BOUNCES 12
#define METAL_BOUNCE_END 8
#define LIGHT_SAMPLES 7
#define BACKGROUND_COLOUR 0xFF15121B

extern TextureMap worldTexture;

RayTriangleIntersection getClosestIntersection(glm::vec3 cameraPosition, glm::vec3 rayDirection, std::vector<ModelTriangle> triangles);

void RenderRayTracedScene(DrawingWindow& window, std::vector<Object> faces, Camera& c, Light l, int frame);