#pragma once
#include "Triangles.h"
#include <ModelTriangle.h>
#include <Utils.h>
#include "Material.h"
#include <fstream>
#include <map>

struct Object {
	std::string name;
	std::vector<ModelTriangle> tris;
	std::string m;

	Object(std::string name);
};

std::vector<Object> ReadOBJ(const std::string& fileName, float scalar);

void ReadMTL(const std::string& fileName, const std::string& filePath);