#pragma once
#include "Interpolate.h"
#include "Camera.h"

enum class AnimType {Look, LookHard, Rot, Loc, Orbit, Zoom, TransLocal, TransGlobal, Engine};

struct AnimTrack {

	glm::vec3 pos_end;
	glm::vec3 look_end;
	glm::mat3 rot_end;
	float zoom_end;
	float orbit_speed;
	glm::vec3 orbit_centre;
	glm::vec3 trans_local;
	glm::vec3 trans_global;
	EngineType engine;

	int frame_start;
	int frame_end;

	AnimType animType;

	void updateAttribute(Camera& c, float frame);

	AnimTrack(float zoom_end, int start, int end);
	AnimTrack(EngineType engine, int start);
	AnimTrack(glm::vec3 orbit_centre, float orbit_speed, int start, int end);
	AnimTrack(glm::vec3 target, int start, int end, AnimType type);
	AnimTrack(glm::mat3 rot, int start);
};