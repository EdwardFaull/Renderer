#include <vector>

#define CLIP_FAR 0.01f
#define CLIP_CLOSE 20.0f

std::vector<std::vector<double>> initBuffer(int W, int H);

extern std::vector<std::vector<double>> depthBuffer;