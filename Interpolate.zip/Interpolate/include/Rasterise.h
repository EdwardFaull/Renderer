#pragma once
#include "Triangles.h"
#include "Camera.h"
#include "Depth.h"
#include <ModelTriangle.h>
#include "Object.h"

#define WIREFRAME 0
#define FILLED 1

CanvasPoint getCanvasIntersectionPoint(Camera& c, glm::vec3 vertexPosition, float W, float H);

void RenderRasterisedScene(DrawingWindow& window, std::vector<Object> objects, Camera &c, int type);

CanvasTriangle getRenderTriangle(ModelTriangle tri, Camera& c, int W, int H);