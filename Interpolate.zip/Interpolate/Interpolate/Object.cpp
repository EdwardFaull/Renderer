#pragma once
#include "Object.h"

void ReadMTL(const std::string& fileName, const std::string& filePath) {
	std::map<std::string, Material> materials;
	std::map<std::string, TextureMap> textures;

	std::ifstream inputStream(filePath + fileName);
	std::string nextLine;

	while (std::getline(inputStream, nextLine)) {
		std::vector<std::string> fields = split(nextLine, ' ');
		if (fields.at(0).compare("newmtl") == 0) {
			Colour colour(192, 192, 192);
			Colour specular(255, 255, 255);
			float IoR = 1.45;
			float specular_exponent = SPECULAR_EXP;
			MatType matType = MatType::Specular;
			std::string diffTex = "";
			std::string bumpTex = "";
			std::string matName = fields[1];
			colour.name = matName;
			float roughness = 0;
			ShadingType shading = ShadingType::Flat;

			std::getline(inputStream, nextLine);
			while (nextLine.compare("") != 0) {
				std::vector<std::string> fields = split(nextLine, ' ');
				if (fields.at(0).compare("Kd") == 0) {
					colour.red = 255 * std::stof(fields[1]);
					colour.green = 255 * std::stof(fields[2]);
					colour.blue = 255 * std::stof(fields[3]);
				}
				if (fields.at(0).compare("Ks") == 0) {
					specular.red = 255 * std::stof(fields[1]);
					specular.green = 255 * std::stof(fields[2]);
					specular.blue = 255 * std::stof(fields[3]);
				}
				if (fields.at(0).compare("Ni") == 0) {
					IoR = std::stof(fields[1]);
				}
				if (fields.at(0).compare("Ns") == 0) {
					specular_exponent = std::stof(fields[1]);
				}
				if (fields.at(0).compare("map_Kd") == 0) {
					std::string texPath = fields[1];
					TextureMap t(filePath + texPath);
					textures.insert({ texPath, t });
					diffTex = texPath;
				}
				if (fields[0].compare("map_Bump") == 0) {
					std::string texPath = fields[1];
					TextureMap t(filePath + texPath);
					textures.insert({ texPath, t });
					bumpTex = texPath;
				}
				if (fields[0].compare("d") == 0) {
					float opacity = std::stof(fields[1]);
					if (opacity == 0) matType = MatType::Refractive;
				}
				if (fields[0].compare("r") == 0) {
					roughness = std::stof(fields[1]);
				}
				if (fields[0].compare("s") == 0) {
					shading = ShadingType::Smooth;
				}
				if (fields[0].compare("illum") == 0) {
					int illum = std::stoi(fields[1]);
					if (illum == 2) matType = MatType::Metallic;
				}
				std::getline(inputStream, nextLine);
			}
			Material m = Material(matName, matType, shading);
			m.colour = colour;
			m.specColour = specular;
			m.IoR = IoR;
			m.specExp = specular_exponent;
			m.diffuseTextureID = diffTex;
			m.bumpTextureID = bumpTex;
			m.roughness = roughness;

			materials.insert({ matName, m });
		}
	}
	materialAtlas = materials;
	textureAtlas = textures;
	
}

std::vector<int> getVertexInfo(std::string info) {
	std::vector<std::string> splits = split(info, '/');
	std::vector<int> result;
	for (std::string s : splits) {
		if (s != "")
			result.push_back(std::stoi(s) - 1);
		else
			result.push_back(-1);
	}
	return result;
}

std::vector<Object> ReadOBJ(const std::string& fileName, float scalar) {
	std::vector<Object> objects;
	std::vector<glm::vec3> verts;
	std::vector<glm::vec3> vertNormals;
	std::vector<TexturePoint> vertTexturePoints;
	std::vector<std::string> objectMap;

	std::ifstream inputStream(fileName);
	std::string nextLine;

	Object currentObject("start");

	while (std::getline(inputStream, nextLine)) {
		std::vector<std::string> fields = split(nextLine, ' ');

		//Create a new object
		if (fields[0].compare("o") == 0) {
			if (currentObject.name != "start") {
				objects.push_back(currentObject);
			}
			currentObject = Object(fields[1]);
		}
		else if (fields[0].compare("usemtl") == 0) {
			currentObject.m = fields[1];
		}
		else if (fields[0].compare("v") == 0) {
			verts.push_back(glm::vec3(
				std::stof(fields[1]), std::stof(fields[2]), std::stof(fields[3])) * scalar);
			objectMap.push_back(currentObject.name);
		}
		else if (fields[0].compare("vn") == 0) {
			vertNormals.push_back(glm::vec3(
				std::stof(fields[1]), std::stof(fields[2]), std::stof(fields[3])));
		}
		else if (fields[0].compare("vt") == 0) {
			float x = std::stof(fields[1]);
			float y = std::stof(fields[2]);
			vertTexturePoints.push_back(TexturePoint(x, y));
		}
		else if (fields.at(0).compare("f") == 0) {
			ModelTriangle t;

			std::vector<int> i0 = getVertexInfo(fields[1]);
			std::vector<int> i1 = getVertexInfo(fields[2]);
			std::vector<int> i2 = getVertexInfo(fields[3]);

			t.vertices[0] = verts[i0[0]];
			t.vertices[1] = verts[i1[0]];
			t.vertices[2] = verts[i2[0]];

			if (i0.size() > 1 && i1.size() > 1 && i2.size() > 1) {
				if(i0[1] != -1)
					t.texturePoints[0] = vertTexturePoints[i0[1]];
				if(i1[1] != -1)
					t.texturePoints[1] = vertTexturePoints[i1[1]];
				if (i2[1] != -1)
					t.texturePoints[2] = vertTexturePoints[i2[1]];
				if (i0.size() > 2 && i1.size() > 2 && i2.size() > 2) {
					if (i0[2] != -1)
						t.vertexNormals[0] = vertNormals[i0[2]];
					if (i1[2] != -1)
						t.vertexNormals[1] = vertNormals[i1[2]];
					if (i2[2] != -1)
						t.vertexNormals[2] = vertNormals[i2[2]];
				}
			}

			t.normal = glm::normalize(glm::cross(t.vertices[1] - t.vertices[0], t.vertices[2] - t.vertices[0]));
			t.colour = materialAtlas[currentObject.m].colour;

			currentObject.tris.push_back(t);
		}
	}
	objects.push_back(currentObject);

	bool hasExistingNormals = vertNormals.size() > 0;

	if (!hasExistingNormals) {
		std::vector<glm::vec3> normals;

		for (int j = 0; j < verts.size(); j++) {
			glm::vec3 v = verts[j];
			glm::vec3 normal(0, 0, 0);
			for (Object o : objects) {
				if (o.name.compare(objectMap[j]) == 0) {
					bool isInObject = false;
					for (int i = 0; i < o.tris.size(); i++) {
						if (o.tris[i].vertices[0] == v || o.tris[i].vertices[1] == v || o.tris[i].vertices[2] == v) {
							normal += o.tris[i].normal;
							isInObject = true;
						}
					}
					if (isInObject) break;
				}
			}
			normal = glm::normalize(normal);
			normals.push_back(normal);
		}

		//Assign vertex normals to faces
		for (int i = 0; i < verts.size(); i++) {
			for (int o = 0; o < objects.size(); o++) {
				bool isVertFound = false;
				for (int j = 0; j < objects[o].tris.size(); j++) {
					for (int k = 0; k < 3; k++) {
						if (objects[o].tris[j].vertices[k] == verts[i] && objects[o].name.compare(objectMap[i]) == 0) {
							objects[o].tris[j].vertexNormals[k] = normals[i];
							isVertFound = true;
						}
					}
				}
				if (isVertFound) break;
			}
		}
	}

	return objects;
}

Object::Object(std::string name) {
	this->name = name;
}