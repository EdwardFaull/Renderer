#include "../include/Rasterise.h"

CanvasPoint getCanvasIntersectionPoint(Camera &c, glm::vec3 vertexPosition, float W, float H) {
	//Convert to Camera Space
	glm::vec3 cameraSpaceVertex = (vertexPosition - c.pos) * c.rot;

	//Map vertex to canvas
	float u = W - (c.focalLength * (cameraSpaceVertex.x / cameraSpaceVertex.z) * (W / 2) + W/2);
	float v = (c.focalLength * (cameraSpaceVertex.y / cameraSpaceVertex.z)) * (W / 2) + H/2;

	CanvasPoint canvasPoint(u, v);
	//Fix if vertex is off screen
	if (cameraSpaceVertex.z > 0) {
		canvasPoint = CanvasPoint(W - u, H - v);
	}
	canvasPoint.x = round(canvasPoint.x);
	canvasPoint.y = round(canvasPoint.y);

	//canvasPoint.depth = (1 / glm::length(cameraSpaceVertex));
	canvasPoint.depth = -(1 / cameraSpaceVertex.z);
	canvasPoint.distanceFromCamera = (1 / glm::length(cameraSpaceVertex));
	if (cameraSpaceVertex.z > 0) {
		canvasPoint.depth = -canvasPoint.depth;
		canvasPoint.distanceFromCamera = -canvasPoint.distanceFromCamera;
	}
	return canvasPoint;
}

CanvasTriangle getRenderTriangle(ModelTriangle tri, Camera &c, int W, int H) {
	CanvasTriangle t;
	t.vertices[0] = getCanvasIntersectionPoint(c, tri.vertices[0], W, H);
	t.vertices[1] = getCanvasIntersectionPoint(c, tri.vertices[1], W, H);
	t.vertices[2] = getCanvasIntersectionPoint(c, tri.vertices[2], W, H);

	t.vertices[0].texturePoint = tri.texturePoints[0];
	t.vertices[1].texturePoint = tri.texturePoints[1];
	t.vertices[2].texturePoint = tri.texturePoints[2];
	return t;
}

void RenderRasterisedScene(DrawingWindow &window, std::vector<Object> objects, Camera &c, int type) {
	window.clearPixels();
	if (c.orbit) c.orbitCamera();
	depthBuffer = initBuffer(window.width, window.height);
	for (Object o : objects) {
		Material m = materialAtlas[o.m];
		for (ModelTriangle tri : o.tris) {
			CanvasTriangle t = getRenderTriangle(tri, c, window.width, window.height);
			uint32_t colour = tri.colour.makeColourHex();

			switch (type) {
			case WIREFRAME:
				DrawTriangle(window, t, 0xFFFFFFFF);
				break;
			case FILLED:
				if (m.diffuseTextureID != "") {
					DrawTexturedTriangle(window, t, m.colour, m.diffuseTextureID);
				}
				else {
					DrawFilledTriangle(window, t, colour);
				}
				break;
			}
		}
	}
	window.renderFrame();
}