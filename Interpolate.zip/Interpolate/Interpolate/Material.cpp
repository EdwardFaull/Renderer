#pragma once
#include "Material.h"

Material::Material(std::string name, MatType matType, ShadingType shadingType) {
	this->matType = matType;
	this->name = name;
	this->shadingType = shadingType;
	diffuseTextureID = "";
	bumpTextureID = "";
}

Material::Material() {
	matType = MatType::Specular;
	name = "Material";
	colour = Colour(192, 192, 192);
	specColour = Colour(255, 255, 255);
	shadingType = ShadingType::Smooth;
	IoR = 1.45;
	diffuseTextureID = "";
	bumpTextureID = "";
	roughness = 0.0f;
}

std::map<std::string, Material> materialAtlas;
std::map<std::string, TextureMap> textureAtlas;