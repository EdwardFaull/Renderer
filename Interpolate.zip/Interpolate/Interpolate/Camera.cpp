#include "../include/Camera.h"
#include <iostream>

glm::mat3 yMatrix(float theta) {
	glm::mat3 m(
		glm::vec3(cos(theta), 0.0, -sin(theta)),
		glm::vec3(0.0, 1.0, 0.0),
		glm::vec3(sin(theta), 0.0, cos(theta)));
	return m;
}

glm::mat3 xMatrix(float theta) {
	glm::mat3 m(
		glm::vec3(1.0, 0.0, 0.0),
		glm::vec3(0.0, cos(theta), sin(theta)),
		glm::vec3(0.0, -sin(theta), cos(theta)));
	return m;
}

void Camera::rotX(float theta) {
	rot = rot * xMatrix(theta);
}

void Camera::rotY(float theta) {
	rot = rot * yMatrix(theta);
}

Camera::Camera(glm::vec3 pos, float f) {
	focalLength = f;
	this->pos = pos;
	this->rot = glm::mat3(
		1, 0, 0,
		0, 1, 0,
		0, 0, 1
	);
	engine = EngineType::Wireframe;
	orbit = false;
	orbitCenter = glm::vec3(0, 0, 0);
}

void Camera::orbitCamera() {
	orbitMat = yMatrix(-orbitSpeed);
	pos = ((pos - orbitCenter) * orbitMat) + orbitCenter;
	rot = lookAt(orbitCenter, pos);
}

glm::mat3 lookAt(glm::vec3 target, glm::vec3 pos) {
	glm::vec3 forward = target - pos;
	forward = glm::normalize(forward);
	glm::vec3 side = glm::cross(forward, glm::vec3(0, 1, 0));
	glm::vec3 up = glm::cross(forward, side);

	glm::mat3 rot = glm::mat3(
		glm::normalize(side), -glm::normalize(up), -forward
	);
	return rot;
}