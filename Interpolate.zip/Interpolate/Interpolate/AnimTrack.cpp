#include "AnimTrack.h"

void AnimTrack::updateAttribute(Camera& c, float frame) {
	float frameVal = pow((frame - frame_start) / (frame_end - frame_start), 5);
	switch (animType) {
	case AnimType::Loc:
	{
		c.pos = pos_end;
	}
		break;	
	case AnimType::Look:
	{
		glm::mat3 rotation = lookAt(look_end, c.pos);
		glm::mat3 finalRotation = lerp(c.rot, rotation, frameVal);
		c.rot = finalRotation;
	}
		break;
	case AnimType::LookHard:
	{
		c.rot = lookAt(look_end, c.pos);
	}
	break;
	case AnimType::Rot:
	{
		c.rot = this->rot_end;
	}
	break;
	case AnimType::Zoom:
	{
		float finalZoom = lerp(c.focalLength, zoom_end, frameVal);
		c.focalLength = finalZoom;
	}
		break;
	case AnimType::Orbit:
	{
		c.orbitCenter = orbit_centre;
		c.orbitSpeed = orbit_speed;
		c.orbitCamera();
	}
		break;
	case AnimType::TransLocal:
	{
		glm::vec3 transStep = trans_local / (float)(frame_end - frame_start);
		c.pos += transStep[0] * c.rot[0] + transStep[1] * c.rot[1] + transStep[2] * c.rot[2];
	}
		break;
	case AnimType::TransGlobal:
	{
		glm::vec3 transStep = trans_global / (float)(frame_end - frame_start);
		c.pos += transStep;
	}
		break;
	case AnimType::Engine:
		c.engine = engine;
		break;
	}
}

AnimTrack::AnimTrack(glm::vec3 target, int start, int end, AnimType type) {
	switch (type) {
	case AnimType::Loc:
		this->pos_end = target;
		break;
	case AnimType::Look:
	case AnimType::LookHard:
		this->look_end = target;
		break;
	case AnimType::TransLocal:
		this->trans_local = target;
		break;
	case AnimType::TransGlobal:
		this->trans_global = target;
		break;
	}
	this->frame_start = start;
	this->frame_end = end;
	animType = type;
}

AnimTrack::AnimTrack(float zoom_end, int start, int end) {
	this->zoom_end = zoom_end;
	this->frame_start = start;
	this->frame_end = end;
	this->animType = AnimType::Zoom;
}

AnimTrack::AnimTrack(glm::vec3 orbit_centre, float orbit_speed, int start, int end) {
	this->orbit_centre = orbit_centre;
	this->orbit_speed = orbit_speed;
	this->frame_start = start;
	this->frame_end = end;
	this->animType = AnimType::Orbit;
}

AnimTrack::AnimTrack(EngineType engine, int start) {
	this->engine = engine;
	this->frame_start = start;
	this->frame_end = start + 1;
	this->animType = AnimType::Engine;
}

AnimTrack::AnimTrack(glm::mat3 rot, int start) {
	this->rot_end = rot;
	this->frame_start = start;
	this->frame_end = start + 1;
	this->animType = AnimType::Rot;
}