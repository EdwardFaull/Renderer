#include "Ray.h"

std::default_random_engine generator;
std::uniform_real_distribution<float> distribution(-0.5f, 0.5f);

/*

		TODO LIST
===========================
Gouraud Shading - DONE
Rasteriser Perspective Correction - DONE
Soft Shadows - DONE
Mirrors - DONE
Metals - DONE
Environment Maps - DONE
Bump Maps - DONE
Refraction - NEED TO BEND SHADOW (BUT OTHERWISE DONE)
Animation - DONE
Scene - DONE
Scene Formatting - 
Scripting - DONE
Rendering - 

*/

TextureMap worldTexture;

uint32_t getPixelColour(RayTriangleIntersection r, Light l, Camera& camera, std::vector<Object> objects, int bounce);

bool validateIntersection(glm::vec3 possibleSolution) {
	float u = possibleSolution.y;
	float v = possibleSolution.z;
	if (
		(u >= 0.0f) && (u <= 1.0f) &&
		(v >= 0.0f) && (v <= 1.0f) &&
		(u + v) <= 1.0f
		)
		return true;
	return false;
}

std::vector<glm::vec3> getPerpendicularVectors(glm::vec3 v) {
	glm::vec3 axisVec(0, 1, 0);
	if (abs(glm::dot(axisVec, v)) > 0.001f) {
		axisVec = glm::vec3(1, 0, 0);
	}
	glm::vec3 axis1 = glm::cross(v, axisVec);
	glm::vec3 axis2 = glm::cross(v, axis1);

	return { axis1, axis2 };
}

glm::vec3 cast(ModelTriangle triangle, glm::vec3 pos, glm::vec3 ray) {
	glm::vec3 e0 = triangle.vertices[1] - triangle.vertices[0];
	glm::vec3 e1 = triangle.vertices[2] - triangle.vertices[0];
	glm::vec3 SPVector = pos - triangle.vertices[0];
	glm::mat3 DEMatrix(-ray, e0, e1);
	glm::vec3 possibleSolution = glm::inverse(DEMatrix) * SPVector;

	return possibleSolution;
}

RayTriangleIntersection getClosestIntersection(glm::vec3 cameraPosition, glm::vec3 rayDirection, std::vector<Object> objects, bool ignoreGlass) {
	RayTriangleIntersection r;
	r.distanceFromCamera = INT_MAX;
	r.triangleIndex = -1;
	r.objectIndex = -1;
	r.incidentRay = rayDirection;

	int J = objects.size();
	for (int j = 0; j < J; j++) {
		int I = objects[j].tris.size();
		for (int i = 0; i < I; i++) {
			if (materialAtlas[objects[j].m].matType != MatType::Refractive || !ignoreGlass) {
				glm::vec3 possibleSolution = cast(objects[j].tris[i], cameraPosition, rayDirection);
				bool isValid = validateIntersection(possibleSolution);
				if (possibleSolution.x > 0 && possibleSolution.x < r.distanceFromCamera && isValid) {
					glm::vec3 intersectionPoint = cameraPosition + rayDirection * possibleSolution.x;

					r = RayTriangleIntersection(intersectionPoint, abs(possibleSolution.x), objects[j].tris[i], rayDirection, i, j);
					r.u = possibleSolution.y;
					r.v = possibleSolution.z;
				}
			}
		}
	}

	return r;
}

/*
RayTriangleIntersection shadowCast(glm::vec3 renderPoint, glm::vec3 rayDirection, std::vector<Object> objects) {
	RayTriangleIntersection r;
	r.distanceFromCamera = INT_MAX;
	r.triangleIndex = -1;
	r.objectIndex = -1;
	r.incidentRay = rayDirection;

	int J = objects.size();
	for (int j = 0; j < J; j++) {
		int I = objects[j].tris.size();
		for (int i = 0; i < I; i++) {
			if (materialAtlas[objects[j].m].matType != MatType::Refractive) {
				glm::vec3 possibleSolution = cast(objects[j].tris[i], renderPoint, rayDirection);
				bool isValid = validateIntersection(possibleSolution);
				if (possibleSolution.x > 0 && possibleSolution.x < r.distanceFromCamera && isValid) {
					glm::vec3 intersectionPoint = renderPoint + rayDirection * possibleSolution.x;
					r = RayTriangleIntersection(intersectionPoint, possibleSolution.x, objects[j].tris[i], rayDirection, i, j);
					r.u = possibleSolution.y;
					r.v = possibleSolution.z;
				}
			}
		}
	}
	return r;
}

RayTriangleIntersection refractCast(glm::vec3 renderPoint, glm::vec3 rayDirection, std::vector<Object> objects) {
	RayTriangleIntersection r;
	r.distanceFromCamera = INT_MAX;
	r.triangleIndex = -1;
	r.objectIndex = -1;
	r.incidentRay = rayDirection;

	int J = objects.size();
	for (int j = 0; j < J; j++) {
		int I = objects[j].tris.size();
		for (int i = 0; i < I; i++) {
			glm::vec3 possibleSolution = cast(objects[j].tris[i], renderPoint, rayDirection);
			bool isValid = validateIntersection(possibleSolution);
			if (possibleSolution.x > 0 && possibleSolution.x < r.distanceFromCamera && isValid) {
				glm::vec3 intersectionPoint = renderPoint + rayDirection * possibleSolution.x;
				r = RayTriangleIntersection(intersectionPoint, possibleSolution.x, objects[j].tris[i], rayDirection, i, j);
				r.u = possibleSolution.y;
				r.v = possibleSolution.z;
			}
		}
	}
	return r;
}
*/

glm::vec3 phongNormal(RayTriangleIntersection r, Material mat) {
	if (mat.shadingType == ShadingType::Flat)
		return r.intersectedTriangle.normal;

	return glm::normalize((1 - r.u - r.v) * r.intersectedTriangle.vertexNormals[0]
		+ r.u * r.intersectedTriangle.vertexNormals[1]
		+ r.v * r.intersectedTriangle.vertexNormals[2]);
}

float shadowFac(RayTriangleIntersection r, Light l, std::vector<Object> objects, Material mat, glm::vec3 surfaceNormal) {
	if (r.objectIndex < 0 || r.triangleIndex < 0) return 0.0;

	glm::vec3 renderPoint = r.intersectionPoint;

	float brightness = l.radius;

	//Get vectors perpendicular to incident light direction (for displacing light points)
	glm::vec3 directionToLightSource = glm::normalize(l.pos - renderPoint);
	auto axes = getPerpendicularVectors(directionToLightSource);
	glm::vec3 lightAxis1 = axes[0];
	glm::vec3 lightAxis2 = axes[1];

	for (glm::vec2 lightPoint : l.lightPoints) {
		glm::vec3 lightPosition = l.pos + lightPoint.x * lightAxis1 + lightPoint.y * lightAxis2;
		glm::vec3 direction = glm::normalize(lightPosition - renderPoint);

		RayTriangleIntersection shadow = getClosestIntersection(renderPoint + surfaceNormal * SHADOW_BIAS, direction, objects, true);

		float distToLight = glm::distance(lightPosition, renderPoint);
		float distToHit = glm::distance(shadow.intersectionPoint, renderPoint);

		//Ordered in ascending order of distance to centre, so can break immediately instead of looking for min.
		if (distToLight <= distToHit || shadow.triangleIndex == -1) {
			float lightPointLength = glm::length(lightPoint);
			brightness = lightPointLength;
			break;
		}
	}
	return (l.radius - brightness) / l.radius;
}

glm::vec3 getReflectionDir(RayTriangleIntersection r, glm::vec3 incident, Material mat, glm::vec3 surfaceNormal) {
	glm::vec3 normal = surfaceNormal;
	return incident - 2.0f * normal * glm::dot(normal, incident);
}

glm::vec3 lightFac(RayTriangleIntersection r, Light l, float shadow, Material mat, glm::vec3 surfaceNormal) {
	float distance = glm::distance(r.intersectionPoint, l.pos);
	float energy = l.intensity / (2 * PI * distance * distance);;

	float angle = glm::dot(surfaceNormal, glm::normalize(l.pos - r.intersectionPoint));

	float lightIntensity = energy * angle * shadow;

	glm::vec3 colour(l.colour.red, l.colour.green, l.colour.blue);
	colour = glm::normalize(colour);

	return colour * lightIntensity;
}

float specularFac(RayTriangleIntersection r, Light l, Camera& c, Material mat, glm::vec3 surfaceNormal) {
	glm::vec3 hit = r.intersectionPoint;
	glm::vec3 lightDir = glm::normalize(l.pos - hit);
	glm::vec3 cameraDir = glm::normalize(hit - c.pos);
	glm::vec3 reflection = getReflectionDir(r, lightDir, mat, surfaceNormal);
	return std::max(0.0f, glm::dot(reflection, cameraDir));
}

Colour ambientMultiply(Colour c, glm::vec3 y) {
	glm::vec3 ambientVector(c.red, c.green, c.blue);
	ambientVector = glm::normalize(ambientVector) * AMBIENT_MINIMUM;

	c.red = std::max(c.red * y.r, ambientVector.r);
	c.green = std::max(c.green * y.g, ambientVector.g);
	c.blue = std::max(c.blue * y.b, ambientVector.b);

	return c;
}

Colour sampleTexture(RayTriangleIntersection r, std::string id) {
	float tp_x = ((1 - r.u - r.v) * r.intersectedTriangle.texturePoints[0].x
		+ r.u * r.intersectedTriangle.texturePoints[1].x
		+ r.v * r.intersectedTriangle.texturePoints[2].x) * textureAtlas[id].width;
	float tp_y = ((1 - r.u - r.v) * r.intersectedTriangle.texturePoints[0].y
		+ r.u * r.intersectedTriangle.texturePoints[1].y
		+ r.v * r.intersectedTriangle.texturePoints[2].y) * textureAtlas[id].height;

	int index = ((int)floor(tp_y) % textureAtlas[id].height) * textureAtlas[id].width + ((int)round(tp_x) % textureAtlas[id].width);
	if (index >= 0 && index < textureAtlas[id].pixels.size()) {
		Colour diffColour(textureAtlas[id].pixels[index]);
		return diffColour;
	}
	return Colour(255, 255, 255);
}

glm::vec2 getEnvironmentCoords(glm::vec3 rayDirection, float H, float W) {
	float radius = W / (2 * PI);
	float meridian = 0;
	float parallel = 0;
	float centralParallel = 0;

	float pitch = asin(glm::dot(rayDirection, glm::vec3(0, 1, 0)));
	float yaw = atan(rayDirection.x / rayDirection.z);

	float y = (H / 2) + radius * (parallel - pitch);
	float x = (W / 2) + radius * (meridian - yaw) * cos(centralParallel);

	return glm::vec2(x, y);
}

uint32_t sampleEnvironmentTexture(glm::vec3 rayDirection) {
	//return BACKGROUND_COLOUR;

	glm::vec2 coords = getEnvironmentCoords(rayDirection, worldTexture.height, worldTexture.width);

	int index = floor(coords.y) * worldTexture.width + round(coords.x);
	if (index >= 0 && index < worldTexture.pixels.size()) {
		return worldTexture.pixels[index];
	}
	return BACKGROUND_COLOUR;
}

uint32_t getReflectionColour(RayTriangleIntersection r, Light l, Camera& camera, std::vector<Object> objects,
	Material mat, glm::vec3 surfaceNormal, int bounce) {

	Colour averageReflectionColour;

	glm::vec3 reflDir = getReflectionDir(r, glm::normalize(camera.pos - r.intersectionPoint), mat, surfaceNormal);

	if (bounce <= METAL_BOUNCE_END) {
		return sampleEnvironmentTexture(reflDir);
	}

	int samples = METAL_SAMPLES;
	if (bounce < LIGHT_BOUNCES) {
		samples = 1;
	}

	for (int i = 0; i < samples; i++) {
		//Calculate roughness direction
		float random1 = distribution(generator);
		float random2 = distribution(generator);
		float random3 = distribution(generator);
		glm::vec3 roughnessDir = mat.roughness * glm::vec3(random1, random2, random3);

		//glm::vec3 roughnessDir = mat.roughness * (random1 * normalAxis1 + random2 * normalAxis2);

		reflDir = glm::normalize(reflDir + roughnessDir);

		RayTriangleIntersection reflectRay = getClosestIntersection(r.intersectionPoint + surfaceNormal * METAL_BIAS, -reflDir, objects, false);
		Colour reflectionColour;
		if (reflectRay.objectIndex != -1) {
			Camera newObserver(r.intersectionPoint - r.incidentRay, camera.focalLength);
			reflectionColour = Colour(getPixelColour(reflectRay, l, newObserver, objects, bounce - 1));
		}
		else {
			reflectionColour = Colour(sampleEnvironmentTexture(reflectRay.incidentRay));
		}
		averageReflectionColour = averageReflectionColour + reflectionColour;
	}

	averageReflectionColour = averageReflectionColour / (float)METAL_SAMPLES;
	return averageReflectionColour.makeColourHex();
}

Colour getSpecularColour(RayTriangleIntersection r, Light l, Camera& camera, std::vector<Object> objects,
	Material mat, glm::vec3 surfaceNormal, Colour c, float shadow) {
	glm::vec3 illumination = lightFac(r, l, shadow, mat, surfaceNormal);
	c = ambientMultiply(c, illumination);

	if (shadow != 0.0f) {
		float specular = specularFac(r, l, camera, mat, surfaceNormal);
		if (specular > 0) {
			specular = SPECULAR_INTENSITY * std::pow(specular, SPECULAR_EXP);
			c = c + ((mat.specColour * specular) / 255.0);
		}
	}
	return c;
}

uint32_t getPixelColour(RayTriangleIntersection r, Light l, Camera& camera, std::vector<Object> objects, int bounce) {
	if ((r.triangleIndex == -1 || r.objectIndex == -1) && (bounce == LIGHT_BOUNCES))
		return BACKGROUND_COLOUR;
	else if (bounce == 0 || (r.triangleIndex == -1 || r.objectIndex == -1))
		return sampleEnvironmentTexture(r.incidentRay);

	Material mat = materialAtlas[objects[r.objectIndex].m];

	//Get colour info
	Colour c = mat.colour;
	if (mat.diffuseTextureID != "") {
		Colour diffColour = sampleTexture(r, mat.diffuseTextureID);
		c = (c * diffColour) / 255.0;
	}

	//Calculate Phong Normals and Normal Map
	glm::vec3 surfaceNormal = r.intersectedTriangle.normal;
	if (SHADING_SCHEME == 0) {
		surfaceNormal = phongNormal(r, mat);
		if (glm::dot(surfaceNormal, glm::normalize(camera.pos - r.intersectionPoint)) < 0
			&& mat.matType != MatType::Refractive) {
			surfaceNormal = -surfaceNormal;
		}
		if (mat.bumpTextureID != "") {
			auto axes = getPerpendicularVectors(surfaceNormal);
			glm::vec3 normalAxis1 = axes[0];
			glm::vec3 normalAxis2 = axes[1];

			Colour normalColour = sampleTexture(r, mat.bumpTextureID);
			glm::vec3 normalVec(normalColour.red, normalColour.green, normalColour.blue);
			normalVec = (normalVec - glm::vec3(128, 128, 0)) / 256.0f;

			glm::vec3 normalOffset = 0.5f * ((normalVec.r * normalAxis1) + (normalVec.g * normalAxis2)) 
				+ (normalVec.b * surfaceNormal);

			surfaceNormal = glm::normalize(normalOffset);
		}
	}

	//Material effects
	if (mat.matType == MatType::Specular) {
		//GOURAUD SHADING (ew)
		float shadow = shadowFac(r, l, objects, mat, surfaceNormal);
		if (SHADING_SCHEME == 1 && mat.shadingType == ShadingType::Smooth) {
			Colour c_v0 = getSpecularColour(r, l, camera, objects, mat, r.intersectedTriangle.vertexNormals[0], c, shadow);
			Colour c_v1 = getSpecularColour(r, l, camera, objects, mat, r.intersectedTriangle.vertexNormals[1], c, shadow);
			Colour c_v2 = getSpecularColour(r, l, camera, objects, mat, r.intersectedTriangle.vertexNormals[2], c, shadow);

			c = c_v0 * (1 - r.v - r.u) + c_v1 * r.u + c_v2 * r.v;
		}
		//PHONG SHADING
		else if (SHADING_SCHEME == 0 || mat.shadingType == ShadingType::Flat) {
			c = getSpecularColour(r, l, camera, objects, mat, surfaceNormal, c, shadow);
		}
	}
	else if (mat.matType == MatType::Metallic) {
		Colour reflectionColour(getReflectionColour(r, l, camera, objects, mat, surfaceNormal, bounce));
		reflectionColour = (reflectionColour * c) / 255.0;
		return reflectionColour.makeColourHex();
	}
	else if (mat.matType == MatType::Refractive) {
		float incidentDot = glm::dot(r.incidentRay, -surfaceNormal);
		float indexRatio;
		glm::vec3 castOffset;

		//If entering medium...
		if (incidentDot >= 0) {
			indexRatio = 1 / mat.IoR;
			castOffset = -surfaceNormal;
		}
		//If exiting medium...
		else {
			//If total internal reflection occurs...
			float incidentAngle = acos(-incidentDot);
			float criticalAngle = asin(1 / mat.IoR);
			if (incidentAngle >= criticalAngle) {
				//Define new observer point (refl is relative to reflection point, not camera)
				Camera newObserver(r.intersectionPoint - r.incidentRay, camera.focalLength);

				Colour reflectionColour(getReflectionColour(r, l, newObserver, objects, mat, -surfaceNormal, bounce));
				reflectionColour = reflectionColour * (mat.colour / (float)255.0f);
				return reflectionColour.makeColourHex();
			}
			indexRatio = mat.IoR / 1;
			castOffset = surfaceNormal;
		}
		glm::vec3 refractionVector = indexRatio * r.incidentRay + -castOffset * (float)(indexRatio * incidentDot - sqrt(1 - pow(indexRatio, 2) * (1 - pow(incidentDot, 2))));
		RayTriangleIntersection refractRay = getClosestIntersection(r.intersectionPoint + castOffset * GLASS_BIAS, refractionVector, objects, false);
		Colour refractColour(getPixelColour(refractRay, l, camera, objects, bounce - 1));
		refractColour = (refractColour * c) / 255.0;
		return refractColour.makeColourHex();
	}

	uint32_t colour = c.makeColourHex();

	return colour;
}

void drawRay(DrawingWindow& window, RayTriangleIntersection r, Light l, Camera& camera, std::vector<Object> objects, int x, int y) {
	uint32_t colour = getPixelColour(r, l, camera, objects, LIGHT_BOUNCES);
	window.setPixelColour(x, y, colour);
}

void RenderThread(DrawingWindow& window, std::vector<Object> objects, Camera& c, Light l, int x_0, int x_1) {
	int W = window.width;
	int H = window.height;

	for (int i = x_0; i < x_1; i++) {
		for (int j = 0; j < H; j++) {
			float u = i - W / 2;
			float v = j - H / 2;

			float x = 2 * u / (W);
			float y = 2 * v / (W);

			glm::vec3 rayDirection(x, -y, -c.focalLength);
			rayDirection = rayDirection * glm::inverse(c.rot);
			rayDirection = glm::normalize(rayDirection);
			RayTriangleIntersection r = getClosestIntersection(c.pos, rayDirection, objects, false);

			drawRay(window, r, l, c, objects, i, j);
		}
	}
}

void RenderRayTracedScene(DrawingWindow& window, std::vector<Object> objects, Camera& c, Light l, int frame) {
	int W = window.width;
	int H = window.height;
	if (c.orbit)
		c.orbitCamera();
	window.clearPixels();

	std::vector<std::thread> threads;

	//IF YOU CAN'T GET THREADED TO WORK, UNCOMMENT THIS LINE AND COMMENT OUT THE REST OF THIS FUNCTION (Except renderFrame)
	RenderThread(window, objects, c, l, 0, window.width);
	/*
	for (int t = 0; t < THREADS; t++) {
		int x_0 = t * (W / THREADS);
		int x_1 = (t + 1) * (W / THREADS);

		threads.push_back(std::thread(RenderThread, std::ref(window), objects, c, l, t * (W / THREADS), (t + 1) * (W / THREADS)));
	}

	for (int t = 0; t < THREADS; t++) {
		threads[t].join();
	}*/

	window.renderFrame();
}
