#include "Interpolate.h"
#include "Triangles.h"
#include "Object.h"
#include "Rasterise.h"
#include "Ray.h"
#include "Camera.h"
#include "AnimTrack.h"
#include <chrono>

#define WIDTH 640
#define HEIGHT 480

void RenderTests() {
	DrawingWindow window = DrawingWindow(WIDTH, HEIGHT, false);
	SDL_Event event;

	std::string filePath = "C:/Users/edwar/Documents/CS/year3/graphics/workbooks/w2/Interpolate/scene/";
	//std::string filePath = "C:/Users/edwar/Documents/CS/year3/graphics/workbooks/w2/Interpolate/Interpolate/";

	worldTexture = TextureMap(filePath + "monbachtal_riverbank_1k.ppm");

	ReadMTL("scene.mtl", filePath);

	std::vector<Object> obj =
		ReadOBJ(filePath + "scene-sphere.obj", 0.5f);

	//Camera c(glm::vec3(-30.0f, 10.0f, -75.0f), 5.0f);
	//c.rot = lookAt(glm::vec3(0, 0, 0), c.pos);
	Camera c(glm::vec3(0.0f, 0, 4), 2.0f);
	c.orbitCenter = glm::vec3(0, 0, 0);
	c.orbitSpeed = 0.025;

	float stepSize = .2;
	float rotSize = 0.1;

	int renderType = 0;

	window.clearPixels();
	window.renderFrame();

	Light l(glm::vec3(0.0f, 1.75f, 0.0f), 150.0f, 0.5f, Colour(255, 255, 255));
	l.generateLightPoints(LIGHT_SAMPLES);

	switch (renderType) {
	case 0:
		RenderRasterisedScene(window, obj, c, WIREFRAME);
		break;
	case 1:
		RenderRasterisedScene(window, obj, c, FILLED);
		break;
	case 2:
		RenderRayTracedScene(window, obj, c, l, 0);
		break;
	}

	int frame = 0;
	while (true) {
		if (window.pollForInputEvents(event)) {
			if (event.key.keysym.sym == SDLK_p) {
				window.saveBMP(filePath + "renders/" + std::to_string(frame));
			}
			if (event.key.keysym.sym == SDLK_w)
				c.pos -= stepSize * c.rot[2];
			else if (event.key.keysym.sym == SDLK_s)
				c.pos += stepSize * c.rot[2];
			else if (event.key.keysym.sym == SDLK_a)
				c.pos -= stepSize * c.rot[0];
			else if (event.key.keysym.sym == SDLK_d)
				c.pos += stepSize * c.rot[0];
			else if (event.key.keysym.sym == SDLK_e)
				c.pos += stepSize * c.rot[1];
			else if (event.key.keysym.sym == SDLK_q)
				c.pos -= stepSize * c.rot[1];

			else if (event.key.keysym.sym == SDLK_UP)
				c.rotX(rotSize);
			else if (event.key.keysym.sym == SDLK_DOWN)
				c.rotX(0 - rotSize);
			else if (event.key.keysym.sym == SDLK_LEFT)
				c.rotY(rotSize);
			else if (event.key.keysym.sym == SDLK_RIGHT)
				c.rotY(0 - rotSize);

			else if (event.key.keysym.sym == SDLK_o)
				c.orbit = !c.orbit;

			else if (event.key.keysym.sym == SDLK_1)
				renderType = 0;
			else if (event.key.keysym.sym == SDLK_2)
				renderType = 1;
			else if (event.key.keysym.sym == SDLK_3)
				renderType = 2;
		}

		auto start = std::chrono::high_resolution_clock::now();

		switch (renderType) {
		case 0:
			RenderRasterisedScene(window, obj, c, WIREFRAME);
			break;
		case 1:
			RenderRasterisedScene(window, obj, c, FILLED);
			break;
		case 2:
			RenderRayTracedScene(window, obj, c, l, 0);
			break;
		}

		auto stop = std::chrono::high_resolution_clock::now();

		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);

		std::cout << "Frame completed in " << (duration.count() / 1000.0f) << "s" << std::endl;
	}
}

void RenderAnimation() {
	//Define filepaths here
	std::string filePath = "scene/";
	std::string worldTextureFile = "monbachtal_riverbank_1k.ppm";
	std::string materialFile = "scene.mtl";
	std::string objectFile = "scene-inside.obj";

	//Define animation keyframes
	std::vector<AnimTrack> anims = {
		//Setup
		AnimTrack(EngineType::Raytraced, 195),
		AnimTrack(glm::vec3(0, -10, 0), 0, 72, AnimType::TransLocal),

		//Orbit
		AnimTrack(glm::vec3(0, 0, -77), 35, 210, AnimType::TransLocal),
		AnimTrack(glm::vec3(0, 0, 0), 0.038348f, 0, 72),

		//Jump to raytraced
		AnimTrack(glm::vec3(0, 0, 10.519f), 195, 196, AnimType::Loc),
		AnimTrack(glm::mat3(glm::vec3(1, 0, 0), glm::vec3(0, 1, 0), glm::vec3(0, 0, 1)), 195),

		//Zoom Out
		AnimTrack(2.0f, 180, 210),

		//Look at flat-bunny
		AnimTrack(glm::vec3(-2.135, 0, 0.7), 210, 234, AnimType::Look),
		AnimTrack(glm::vec3(-2.135, 0, 0.7), 235, 246, AnimType::LookHard),
		//Look at smooth-bunny
		AnimTrack(glm::vec3(2.135, 0, 0.7), 246, 270, AnimType::Look),
		AnimTrack(glm::vec3(2.135, 0, 0.7), 271, 282, AnimType::LookHard),
		//Loot at phong-sphere
		AnimTrack(glm::vec3(2.135, 0, -1.89), 282, 306, AnimType::Look),
		AnimTrack(glm::vec3(2.135, 0, -1.89), 307, 318, AnimType::LookHard),
		//Look at mirrors
		AnimTrack(glm::vec3(0, 0, -4.39), 318, 342, AnimType::Look),
		AnimTrack(glm::vec3(0, 0, -4.39), 343, 354, AnimType::LookHard),

		//Move through museum
		AnimTrack(glm::vec3(0, 0, -6), 210, 340, AnimType::TransGlobal)
	};

	int animLength = 0;
	int animStart = INT_MAX;
	for (const AnimTrack& a : anims) {
		if (a.frame_end > animLength)
			animLength = a.frame_end;
		if (a.frame_start < animStart)
			animStart = a.frame_start;
	}
	animStart = 195;

	
	DrawingWindow window = DrawingWindow(WIDTH, HEIGHT, false);
	SDL_Event event;

	worldTexture = TextureMap(filePath + worldTextureFile);
	ReadMTL(materialFile, filePath);
	std::vector<Object> obj = ReadOBJ(filePath + objectFile, 0.5f);

	Camera c(glm::vec3(-30.0f, 10.0f, -75.0f), 4.0f);
	c.rot = lookAt(glm::vec3(0, 0, 0), c.pos);

	Light l(glm::vec3(0.0f, 1.75f, 0.0f), 150.0f, 0.5f, Colour(255, 255, 255));
	l.generateLightPoints(LIGHT_SAMPLES);

	int frame = animStart;
	while (frame < animLength) {
		for (AnimTrack a : anims) {
			if (a.frame_start <= frame && a.frame_end > frame) {
				a.updateAttribute(c, frame);
			}
		}

		if (frame == 343) {
			std::cout << c.pos.x << " " << c.pos.y << " " << c.pos.z << std::endl;
			std::cout << c.rot[0].x << " " << c.rot[0].y << " " << c.rot[0].z << std::endl;
			std::cout << c.rot[1].x << " " << c.rot[1].y << " " << c.rot[1].z << std::endl;
			std::cout << c.rot[2].x << " " << c.rot[2].y << " " << c.rot[2].z << std::endl;
		}

		auto start = std::chrono::high_resolution_clock::now();

		switch (c.engine) {
		case EngineType::Wireframe:
			RenderRasterisedScene(window, obj, c, WIREFRAME);
			break;
		case EngineType::Rasterised:
			RenderRasterisedScene(window, obj, c, FILLED);
			break;
		case EngineType::Raytraced:
			RenderRayTracedScene(window, obj, c, l, frame);
			break;
		}

		char buff[9];
		std::sprintf(buff, "%04d", frame);
		std::string frameName(buff);

		window.saveBMP("../render/test01/render" + frameName + ".bmp");

		auto stop = std::chrono::high_resolution_clock::now();
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
		std::cout << "Frame " << frameName << " completed in " << (duration.count() / 1000.0f) << "s" << std::endl;

		frame++;
	}
	while (true) {
		window.renderFrame();
	}
}

int main( int argc, const char** argv )
{
	//RenderTests();
	RenderAnimation();
	return 0;
}