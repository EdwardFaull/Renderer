#include "../include/Interpolate.h"


glm::vec3 lerp(glm::vec3 a, glm::vec3 b, float c) {
    return a * (1 - c) + b * (c);
}
glm::mat3 lerp(glm::mat3 a, glm::mat3 b, float c) {
    glm::mat3 newMat;
    newMat[0] = glm::normalize(lerp(a[0], b[0], c));
    newMat[1] = glm::normalize(lerp(a[1], b[1], c));
    newMat[2] = glm::normalize(lerp(a[2], b[2], c));
    return newMat;
}

CanvasPoint lerp(CanvasPoint a, CanvasPoint b, float c) {
    float x = a.x * (1 - c) + b.x * c; 
    float y = a.y * (1 - c) + b.y * c;
    float d = a.depth * (1 - c) + b.depth * c;
    CanvasPoint ret(x, y);
    ret.depth = d;
    return ret;
}
TexturePoint lerp(TexturePoint a, TexturePoint b, float c) {
    float x = a.x * (1 - c) + b.x * c;
    float y = a.y * (1 - c) + b.y * c;
    return TexturePoint(x, y);
}
float lerp(float a, float b, float c) {
    return a * (1 - c) + b * (c);
}

float rescale(float x, float upper, float lower, float newUpper, float newLower) {
    x -= lower;
    x /= (upper - lower);
    x *= (newUpper - newLower);
    x += newLower;
    return x;
}

std::vector<float> SingleElementInterpolate(float in, float out, int steps) {
    float diff = out - in;
    steps = steps - 1;
    std::vector<float> result = {};
    for (int i = 0; i <= steps; i++) {
        result.push_back(in + (i * diff) / steps);
    }
    return result;
}

void GreyscaleGradient(DrawingWindow& window) {
    window.clearPixels();
    std::vector<float> gradient = SingleElementInterpolate(0, 255, 256);
    for (size_t y = 0; y < window.height; y++) {
        uint32_t grey = gradient[y];
        for (size_t x = 0; x < window.width; x++) {
            uint32_t colour = (255 << 24) + (int(grey) << 16) + (int(grey) << 8) + int(grey);
            window.setPixelColour(x, y, colour);
        }
    }
}

std::vector<glm::vec3> InterpolateThreeElementValues(glm::vec3 from, glm::vec3 to, int numberOfValues) {
    std::vector<float> r = SingleElementInterpolate(from.r, to.r, numberOfValues);
    std::vector<float> g = SingleElementInterpolate(from.g, to.g, numberOfValues);
    std::vector<float> b = SingleElementInterpolate(from.b, to.b, numberOfValues);

    std::vector<glm::vec3> result = {};

    for (int i = 0; i < numberOfValues; i++) {
        glm::vec3 x(r[i], g[i], b[i]);
        result.push_back(x);
    }
    return result;
}

std::vector<std::vector<glm::vec3>> SpectrumGradient(int W, int H) {
    glm::vec3 red(255, 0, 0);
    glm::vec3 green(0, 255, 0);
    glm::vec3 blue(0, 0, 255);
    glm::vec3 yellow(255, 255, 0);
    std::vector<glm::vec3> left = InterpolateThreeElementValues(red, yellow, H);
    std::vector<glm::vec3> right = InterpolateThreeElementValues(blue, green, W);

    std::vector<std::vector<glm::vec3>> spectrum;
    for (int i = 0; i < W; i++) {
        std::vector<glm::vec3> row = InterpolateThreeElementValues(left[i], right[i], W);
        spectrum.push_back(row);
    }
    return spectrum;
}

std::vector<CanvasPoint> InterpolatePoints(CanvasPoint to, CanvasPoint from) {
    std::vector<CanvasPoint> result;

    float xDiff = to.x - from.x;
    float yDiff = to.y - from.y;

    float dDiff = to.depth - from.depth;

    float t_xDiff = to.texturePoint.x - from.texturePoint.x;
    float t_yDiff = to.texturePoint.y - from.texturePoint.y;

    float numberOfSteps = std::max(std::abs(xDiff), std::abs(yDiff));

    float xStepSize = xDiff / numberOfSteps;
    float yStepSize = yDiff / numberOfSteps;
    float dStepSize = dDiff / numberOfSteps;
    float t_xStepSize = t_xDiff / numberOfSteps;
    float t_yStepSize = t_yDiff / numberOfSteps;

    for (int i = 0; i < numberOfSteps; i++) {
        float x = from.x + (xStepSize * i);
        float y = from.y + (yStepSize * i);

        CanvasPoint c(x, y);
        c.texturePoint = TexturePoint(0, 0);

        c.depth = from.depth + (dStepSize * i);
        c.texturePoint.x = from.texturePoint.x + (t_xStepSize * i);
        c.texturePoint.y = from.texturePoint.y + (t_yStepSize * i);

        result.push_back(c);
    }
    result.push_back(to);
    return result;
}

std::vector<TexturePoint> InterpolateTexturePoints(CanvasPoint to, CanvasPoint from) {
    std::vector<TexturePoint> result;
    TexturePoint t_from = from.texturePoint;
    TexturePoint t_to = to.texturePoint;

    float xDiff = to.x - from.x;
    float yDiff = to.y - from.y;

    float t_xDiff = t_to.x - t_from.x;
    float t_yDiff = t_to.y - t_from.y;

    float numberOfSteps = std::max(std::abs(xDiff), std::abs(yDiff));

    float xStepSize = t_xDiff / numberOfSteps;
    float yStepSize = t_yDiff / numberOfSteps;

    for (int i = 0; i < numberOfSteps; i++) {
        float x = t_from.x + (xStepSize * i);
        float y = t_from.y + (yStepSize * i);

        result.push_back(TexturePoint(x, y));
    }
    result.push_back(to.texturePoint);
    return result;
}