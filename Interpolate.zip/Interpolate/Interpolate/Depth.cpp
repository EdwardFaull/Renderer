#include "../include/Depth.h"

std::vector<std::vector<double>> initBuffer(int W, int H) {
	std::vector<std::vector<double>> buffer;
	for (int i = 0; i < H; i++) {
		buffer.push_back(std::vector<double>(W, 0));
	}
	return buffer;
}

std::vector<std::vector<double>> depthBuffer;