#include <Light.h>

Light::Light(glm::vec3 pos, float i, float r, Colour c) {
	this->pos = pos;
	this->intensity = i;
	this->radius = r;
	this->colour = c;
}

void Light::generateLightPoints(float samples) {
	std::vector<glm::vec2> points;

	float angle_step = 360.0f / samples;
	float angle_offset = 0.0f;
	float mag_step = radius / samples;

	std::vector<float> magnitudes;
	std::vector<float> thetas;
	
	points.push_back(glm::vec2(0, 0));
	for (int m = 1; m < samples; m++) {
		float magnitude = mag_step * m;
		for (int i = 0; i <= samples - 1; i++) {
			float angle = (angle_step * i + angle_offset) / (180/PI);
			for (int j = 0; j < samples - 1; j++) {
				glm::vec2 p(magnitude * sin(angle), magnitude * cos(angle));
				bool inPoints = false;
				for (auto point : points) {
					if (point == p) { inPoints = true; break; }
				}
				if (!inPoints) { points.push_back(p); }
			}
		}
		if (angle_offset == 0.0f) angle_offset = angle_step / 2.0f;
		else angle_offset = 0.0f;
	}

	lightPoints = points;
}