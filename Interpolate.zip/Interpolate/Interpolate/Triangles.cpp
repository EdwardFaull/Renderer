#include "../include/Triangles.h"

std::vector<std::vector<glm::vec3>> spectrum;

TexturePoint derp(CanvasPoint v1, CanvasPoint v2, float q);

void DrawLine(DrawingWindow& window, CanvasPoint from, CanvasPoint to, uint32_t colour) {

	std::vector<CanvasPoint> points = InterpolatePoints(from, to);

	for (int i = 0; i < points.size(); i++) {
		int x = round(points[i].x);
		int y = round(points[i].y);
		float d = points.at(i).depth;
		if (x >= 0 && x < window.width && y >= 0 && y < window.height) {
			if (d > depthBuffer[y][x] && d > 0) {
				window.setPixelColour(x, y, colour);
				depthBuffer[y][x] = d;
			}
		}
	}
}

void DrawLine(DrawingWindow& window, CanvasPoint from, CanvasPoint to, Colour c, std::string t) {
	//Do rounding (ugly but works)
	to.x = ceil(to.x);
	to.y = round(to.y);
	to.texturePoint.x = ceil(to.texturePoint.x * textureAtlas[t].width);
	to.texturePoint.y = round(to.texturePoint.y * textureAtlas[t].height);

	from.x = floor(from.x);
	from.y = round(from.y);
	from.texturePoint.x = floor(from.texturePoint.x * textureAtlas[t].width);
	from.texturePoint.y = round(from.texturePoint.y * textureAtlas[t].height);

	std::vector<CanvasPoint> points = InterpolatePoints(to, from);

	for (int i = 0; i < points.size(); i++) {
		float d = points[i].depth;
		int x = points[i].x;
		int y = points[i].y;

		if (x >= 0 && x < window.width && y >= 0 && y < window.height) {
			if (d > depthBuffer[y][x] && d > 0) {
				float q = ((float)i / (float)points.size());
				TexturePoint tp = derp(from, to, q);
				TexturePoint tp_og = points[i].texturePoint;

				Colour pixelColour(c);
				int index = ((int)floor(tp.y) % textureAtlas[t].height) * textureAtlas[t].width + 
					((int)round(tp.x) % textureAtlas[t].width);

				if (index < textureAtlas[t].pixels.size() && index >= 0) {
					Colour texColour(textureAtlas[t].pixels[index]);
					pixelColour.red *= (float)texColour.red / 255.0f;
					pixelColour.green *= (float)texColour.green / 255.0f;
					pixelColour.blue *= (float)texColour.blue / 255.0f;
				}

				window.setPixelColour(x, y, pixelColour.makeColourHex());
				depthBuffer[y][x] = d;
			}
		}
	}
}

int indexOf(std::vector<CanvasPoint> arr, int y) {
	for (int i = 0; i < arr.size(); i++) {
		if (round(arr.at(i).y) == y)
			return i;
	}
	return 0;
}

void DrawTriangle(DrawingWindow& window, CanvasPoint p1, CanvasPoint p2, CanvasPoint p3, uint32_t colour) {
	DrawLine(window, p1, p2, colour);
	DrawLine(window, p2, p3, colour);
	DrawLine(window, p3, p1, colour);
}

void DrawTriangle(DrawingWindow& window, CanvasTriangle t, uint32_t colour) {
	DrawTriangle(window, t.v0(), t.v1(), t.v2(), colour);
}

void DrawFilledTriangle(DrawingWindow& window, CanvasTriangle t, uint32_t colour) {
	DrawFilledTriangle(window, t.v0(), t.v1(), t.v2(), colour);
}

void DrawFilledTriangle(DrawingWindow& window, CanvasPoint p1, CanvasPoint p2, CanvasPoint p3, uint32_t colour) {
	CanvasTriangle triangle(p1, p2, p3);
	triangle.sortPoints();

	std::vector<CanvasPoint> EdgeTopBottom = InterpolatePoints(triangle.v0(), triangle.v2());
	std::vector<CanvasPoint> EdgeTopMiddle = InterpolatePoints(triangle.v0(), triangle.v1());
	std::vector<CanvasPoint> EdgeBottomMiddle = InterpolatePoints(triangle.v2(), triangle.v1());

	CanvasPoint intercept(EdgeTopBottom.at(indexOf(EdgeTopBottom, triangle.v1().y)).x, triangle.v1().y);

	for (int i = triangle.v2().y; i >= intercept.y; i--) {
		if (i >= 0 && i < window.height) {
			CanvasPoint v1(EdgeBottomMiddle.at(indexOf(EdgeBottomMiddle, i)));
			CanvasPoint v2(EdgeTopBottom.at(indexOf(EdgeTopBottom, i)));
			DrawLine(window, v1, v2, colour);
		}
	}
	for (int i = triangle.v0().y; i < intercept.y; i++) {
		if (i >= 0 && i < window.height) {
			CanvasPoint v1(EdgeTopMiddle.at(indexOf(EdgeTopMiddle, i)));
			CanvasPoint v2(EdgeTopBottom.at(indexOf(EdgeTopBottom, i)));
			DrawLine(window, v1, v2, colour);
		}
	}
}

TexturePoint derp(CanvasPoint v0, CanvasPoint v1, float q) {
	float C0_y = v0.texturePoint.y;
	float C0_x = v0.texturePoint.x;
	float C1_y = v1.texturePoint.y;
	float C1_x = v1.texturePoint.x;

	float ratio_y = lerp(C0_y * v0.depth, C1_y * v1.depth, q);
	float ratio_x = lerp(C0_x * v0.depth, C1_x * v1.depth, q);

	float depth = lerp(v0.depth, v1.depth, q);

	float C_y = ratio_y / depth;
	float C_x = ratio_x / depth; 
	return TexturePoint(C_x, C_y);
}

void DrawTexturedTriangle(DrawingWindow& window, CanvasTriangle triangle, Colour colour, std::string texture) {
	triangle.sortPoints();

	float interceptRatio = (triangle.v1().y - triangle.v2().y) / (triangle.v0().y - triangle.v2().y);
	CanvasPoint triIntercept = lerp(triangle.v2(), triangle.v0(), interceptRatio);
	triIntercept.x = round(triIntercept.x); 
	triIntercept.y = round(triIntercept.y);
	triIntercept.texturePoint = derp(triangle.v2(), triangle.v0(), interceptRatio);

	//Bottom Triangle
	for (int i = triangle.v2().y; i >= triIntercept.y; i--) {
		if (i >= 0 && i < window.height) {
			float q = 1 - clamp(rescale(i, ceil(triangle.v2().y), floor(triIntercept.y), 1.0f, 0.0f), 0.0f, 1.0f);
			CanvasPoint v1 = lerp(triangle.v2(), triangle.v1(), q);
			CanvasPoint v2 = lerp(triangle.v2(), triIntercept, q);
			v1.texturePoint = derp(triangle.v2(), triangle.v1(), q);
			v2.texturePoint = derp(triangle.v2(), triIntercept, q);

			DrawLine(window, v1, v2, colour, texture);
		}
	}
	//Top Triangle
	for (int i = triangle.v0().y; i < triIntercept.y; i++) {
		if (i >= 0 && i < window.height) {
			float q = clamp(rescale(i, floor(triIntercept.y), ceil(triangle.v0().y), 1.0f, 0.0f), 0.0f, 1.0f);
			CanvasPoint v1 = lerp(triangle.v0(), triangle.v1(), q);
			CanvasPoint v2 = lerp(triangle.v0(), triIntercept, q);
			v1.texturePoint = derp(triangle.v0(), triangle.v1(), q);
			v2.texturePoint = derp(triangle.v0(), triIntercept, q);

			DrawLine(window, v1, v2, colour, texture);
		}
	}
}